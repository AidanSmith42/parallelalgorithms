#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <omp.h>

void random_array(double* array, int size, int scale){ 
	#pragma omp parallel for default(none) shared(array, size, scale)
	for(int i= 0; i < size; i++){
    unsigned long int to_test;
    arc4random_buf(&to_test , sizeof (to_test));
    to_test = to_test % scale;
	 //unsigned short seed[3] = {omp_get_thread_num(), 0, 0}; 
	//	array[i] = jrand48(&seed[0]);// * scale / RAND_MAX;
	array[i] = to_test; // rand() * scale / RAND_MAX;
	}
}


double sum(double* array, int size){
	double sum =0;
	for(int i=0; i< size; i++){
	sum+=array[i];
	}
return sum;
}


double stdev(double* array, int size){
	double time_s = omp_get_wtime();
	double mean = sum(array, size);
	mean = mean/size;
	double sd = 0;
	#pragma omp parallel for reduction(+:sd)
	for(int i =0; i< size; i++){
		sd += (array[i]-mean)*(array[i]-mean);
		}
	sd = sqrt(sd/size);
	double time_e = omp_get_wtime();
    printf("stdev took %lf sec on %d threads\n", (time_e-time_s),
           omp_get_max_threads());
	return sd;

}


void smooth(double* array, int size, double w){
	double time_s = omp_get_wtime();
	double *arr2;
	arr2= (double*) malloc(sizeof(double)*size);
	arr2[0] = array[0];
	arr2[size-1] = array[size-1];
	//dont do first or last
	#pragma omp parallel for default(none) shared(array, arr2, size,w)
	for(int i=1; i<size-1; i++){
		arr2[i] = array[i]*w +((array[i-1]+array[i+1])*(1-w)/2);
		array[i]=arr2[i];
		}		
//	#pragma omp parallel for default(none) shared(size, array, arr2)
//	for(int i = 0; i < size; i++){ 
//		array[i]= arr2[i];
//		}
    double time_e = omp_get_wtime();
    printf("smoothed array took %lf sec on %d threads\n", (time_e-time_s),
           omp_get_max_threads());
}

void print_array(double * array){
	for(int i = 0; i < 10; i++){	
		printf("%f\n", (array[i]));
	}
}

int main(){
	long SIZE = 1000000000;
	int SCALE = 999;
	double * arr;
	arr = (double*) malloc(sizeof(double)*SIZE);
	
	random_array(arr, SIZE, SCALE);
	//print_array(arr);
	//stdev(arr,SIZE);
	smooth(arr, SIZE, .5);
	//print_array(arr);	
	return 0;

}
