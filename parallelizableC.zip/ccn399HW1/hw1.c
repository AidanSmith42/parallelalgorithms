#include <stdio.h>
#include <math.h>
void random_array(double* array, int size, double scale){
for(int i= 0; i < size; i++){
array[i] = (double) rand() * scale;
}
}


double sum(double* array, int size){
double sum =0;
	for(int i=0; i< size; i++){
	sum+=array[i];
	}
return sum;
}


double stdev(double* array, int size){
	double mean = sum(array, size);
	mean = mean/size;
	double sd = 0;
	for(int i =0; i< size; i++){
	sd += pow(array[i]-mean, 2);
	}
	sd = sqrt(sd/size);
	return sd;
}


void smooth(double* array, int size, double w){
	double* arr2= array;
	arr2[0] = array[0];
	arr2[size-1] = array[size-1];
	//dont do first or last
	for(int i=1; i<size-1; i++){
	arr2[i] = array[i]*w +((array[i-1]+array[i+1])*(1-w)/2);
	}
	array= arr2;
}

void print_array(double * array){
for(int i = 0; i < 10; i++){
printf("%f\n", (array[i]));
}
}

int main(){
int SIZE = 10;
double SCALE = 4;
double Array[SIZE];
double * arr;
arr= Array;
random_array(arr, SIZE, SCALE);
print_array(arr);
printf("%s\n", "SUM and SD");
printf("%f\n", sum(arr, SIZE));

printf("%f\n", stdev(arr, SIZE));
smooth(arr, SIZE, .5);
printf("%s\n", "SMOOTHED ARRAY");
print_array(arr);	
return 0;

}
