/*
Paul Smith 
pthread hw3
ccn399
CPSC 5260


This program uses pthreads to find a defined number of primes in parallel using mutexes 
and condition variables.
*/

#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include <math.h>
#include <unistd.h>

#define NUM_THREADS 8
#define NUM_VALS 8
#define MAXVAL 9999999999999999

int count=0;
unsigned long int primes[NUM_VALS];
pthread_cond_t cond = PTHREAD_COND_INITIALIZER;
pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;


void* wait(void* x)
{
    pthread_mutex_lock(&lock);

    while (count < NUM_VALS)
    {
        printf("Running on %d threads...\n", NUM_THREADS);
        pthread_cond_wait(&cond, &lock);
    }

    pthread_mutex_unlock(&lock);
    return NULL;
}

int isPrime(unsigned long int x){
   
    int flag =1;
    for(int i =2; i <= sqrt(x); i++){
        if(x %i == 0) {     
            flag=0;
            break;
            }
    }
    if(flag==1) return 1;
    else        return 0;

}

void* act(void* x)
{
    while (1)
    {
    pthread_testcancel();
    unsigned long int to_test;
    arc4random_buf (&to_test , sizeof (to_test));
    to_test = to_test % MAXVAL ;
    
    if(isPrime(to_test)){
        pthread_mutex_lock(&lock);
        primes[count]= to_test;
        count++;
        }
    if (count >= NUM_VALS)
        {
        pthread_cond_signal(&cond);
        }

        pthread_mutex_unlock(&lock);
    }

    return NULL;
}




int main(int argc, char *argv[])
{
    pthread_t waiter;
    pthread_t actors[NUM_THREADS];

    pthread_create(&waiter, NULL, wait, NULL);
    for (int i=0; i<NUM_THREADS; i++)
    {
        pthread_create(&actors[i], NULL, act, NULL);
    }

    pthread_join(waiter, NULL);
    for (int i=0; i<NUM_THREADS; i++)
    {
        pthread_cancel(actors[i]);
        pthread_join(actors[i], NULL);
    }
    printf("%d Primes : \n", NUM_VALS);
    for(int i=0; i< NUM_VALS; i++){
        printf("%lu \n", primes[i]);
    }

    return 0;


}
